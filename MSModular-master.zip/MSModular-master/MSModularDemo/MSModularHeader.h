//
//  MSModularHeader.h
//  MSModularDemo
//
//  Created by J on 2017/3/9.
//  Copyright © 2017年 J. All rights reserved.
//

#import "MSService.h"
#import "NSObject+MSFixWarning.h"
#import "MSAppBus.h"
#import "MSCrashProtector.h"
#import "MSSafeContainer.h"

#define KScreenWidth               [[UIScreen mainScreen] bounds].size.width
#define KScreenHeight              [[UIScreen mainScreen] bounds].size.height


