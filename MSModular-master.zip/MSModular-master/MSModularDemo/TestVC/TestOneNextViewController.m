//
//  TestOneNextViewController.m
//  MSModularDemo
//
//  Created by J on 2017/3/10.
//  Copyright © 2017年 J. All rights reserved.
//

#import "TestOneNextViewController.h"
#import "MSModularHeader.h"

@interface TestOneNextViewController ()

@end

@implementation TestOneNextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)doUserUtilityActionWithParams:(NSDictionary*)dic{
    
    TestOneNextViewController* vc = [TestOneNextViewController new];
    vc.view.backgroundColor = [dic objectForKey:@"color" defaultValue:[UIColor whiteColor]];
    
    vc.navigationItem.title = [dic objectForKey:@"title" defaultValue:nil];
    UINavigationController* nav = (UINavigationController*)[UIApplication sharedApplication].keyWindow.rootViewController;
    [nav pushViewController:vc animated:YES];
}
@end
