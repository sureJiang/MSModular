//
//  TestOneViewController.m
//  MSModularDemo
//
//  Created by J on 2017/3/8.
//  Copyright © 2017年 J. All rights reserved.
//

#import "TestOneViewController.h"
#import "MSModularHeader.h"

@interface TestOneViewController ()

@end

@implementation TestOneViewController


- (void)doUserUtilityActionWithParams:(NSDictionary*)dic{
    
    TestOneViewController* vc = [TestOneViewController new];
    vc.view.backgroundColor = [dic objectForKey:@"color" defaultValue:[UIColor whiteColor]];
    
    vc.navigationItem.title = [dic objectForKey:@"title" defaultValue:nil];
    UINavigationController* nav = (UINavigationController*)[UIApplication sharedApplication].keyWindow.rootViewController;
    [nav pushViewController:vc animated:YES];
}
@end
