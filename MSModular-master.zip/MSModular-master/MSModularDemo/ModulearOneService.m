//
//  ModulearOneService.m
//  MSModularDemo
//
//  Created by J on 2017/3/9.
//  Copyright © 2017年 J. All rights reserved.
//

#import "ModulearOneService.h"
#import "MSModularHeader.h"
@interface ModulearOneService()<MSModulearOneProtocol>

@end
@implementation ModulearOneService

MSRegistService(MSModulearOneProtocol)
static NSString *ktestOneViewController   = @"TestOneViewController";
static NSString *ktestNextViewController  = @"TestOneNextViewController";
static NSString *ktestOneViewAction       = @"doUserUtilityActionWithParams:";


- (void)gotoUserControllerWithType:(MSModulearViewType)type andParams:(NSDictionary *)params{

    switch (type) {
        case MSModulearViewTypeCaseOne:{
            [self performTarget:ktestNextViewController action:ktestOneViewAction params:params];
        }
            break;
        case MSModulearViewTypeCaseTwo:{
            [self performTarget:ktestOneViewController action:ktestOneViewAction params:params];
        }
            break;
        default:
            break;
    }
}



#pragma mark - service事件分发
- (void)performTarget:(NSString *)target
               action:(NSString *)actionStr
               params:(NSDictionary *)paramDic{
    
    SEL sel = NSSelectorFromString(actionStr);
    id targetInstance = [NSClassFromString(target) new];
    if(![targetInstance respondsToSelector:sel])return;
    [targetInstance performSelectorFixWarning:sel withObject:paramDic];
}

- (void)serviceDidInit {
}
@end
