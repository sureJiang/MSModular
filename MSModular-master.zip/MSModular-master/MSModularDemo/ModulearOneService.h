//
//  ModulearOneService.h
//  MSModularDemo
//
//  Created by J on 2017/3/9.
//  Copyright © 2017年 J. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ModulearOneService : NSObject

@end
