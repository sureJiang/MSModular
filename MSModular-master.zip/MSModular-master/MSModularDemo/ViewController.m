//
//  ViewController.m
//  MSModularDemo
//
//  Created by J on 2017/3/8.
//  Copyright © 2017年 J. All rights reserved.
//

#import "ViewController.h"
#import "MSModularHeader.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self createUI];
}


-(void)createUI{
    
    CGFloat width  =  (KScreenWidth-20*2-10)*0.5;
    CGFloat height = 40;
    UIButton* showButton = [UIButton buttonWithType:UIButtonTypeCustom];
    showButton.frame = CGRectMake(20, (KScreenHeight-30)*0.5, width, height);
    [showButton addTarget:self action:@selector(caseOne:) forControlEvents:UIControlEventTouchUpInside];
    [showButton setTitle:@"CaseOne" forState:UIControlStateNormal];
    [showButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    showButton.backgroundColor = [UIColor darkGrayColor];
    showButton.layer.cornerRadius = 2;
    [self.view addSubview:showButton];
    
    UIButton* dismissButton = [UIButton buttonWithType:UIButtonTypeCustom];
    dismissButton.frame = CGRectMake(showButton.frame.origin.x+width+10, (KScreenHeight-30)*0.5, width, height);
    [dismissButton addTarget:self action:@selector(caseTwo:) forControlEvents:UIControlEventTouchUpInside];
    [dismissButton setTitle:@"CaseTwo" forState:UIControlStateNormal];
    [dismissButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    dismissButton.backgroundColor = [UIColor darkGrayColor];
    dismissButton.layer.cornerRadius = 2;
    [self.view addSubview:dismissButton];
}

- (void)caseOne:(id)sender {
    
    NSDictionary * dic = @{
                           @"title":@"MSModulearViewTypeCaseOne",
                           @"color":[UIColor orangeColor]
                           };
    id<MSModulearOneProtocol>userService = [MSAppBus service:@protocol(MSModulearOneProtocol)];
    [userService gotoUserControllerWithType:MSModulearViewTypeCaseOne andParams:dic];
}


- (void)caseTwo:(id)sender {
    
    
    NSDictionary * dic = @{
                           @"title":@"MSModulearViewTypeCaseTwo",
                           @"color":[UIColor purpleColor]
                           };
    id<MSModulearOneProtocol>userService = [MSAppBus service:@protocol(MSModulearOneProtocol)];
    [userService gotoUserControllerWithType:MSModulearViewTypeCaseTwo andParams:dic];
}



@end
