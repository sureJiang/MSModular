//
//  MSAppBus.h
//  
//
//  Created by J on 2017/3/8.
//  Copyright © 2017年 J. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MSAppBus : NSObject



+ (id)element:(Class)aclass;



+ (id)service:(Protocol *)serviceProtocol;
+ (BOOL)existService:(Protocol *)serviceProtocol;
+ (void)registerService:(Protocol *)serviceProtocol withImplementClass:(Class)implClass;


+ (Class)unit:(Protocol*)unitProtolcol;
+ (BOOL)existUnit:(Protocol *)unitProtocol;
+ (void)registerUnit:(Protocol *)unitProtocol withUnitClass:(Class)implClass;

@end
