//
//  MSService.h
//  
//
//  Created by J on 2017/3/8.
//  Copyright © 2017年 J. All rights reserved.
//

#import "MSAppBus.h"
#import <UIKit/UIKit.h>


#undef MSRegistService
#define MSRegistService(serviceProtocol) \
+ (void)load { [MSAppBus registerService:@protocol(serviceProtocol) withImplementClass:[self class]]; }

@protocol MSService <NSObject>
/*
 生命周期管理后的初始化方法
 */
- (void)serviceDidInit;

@end



///模块1
#pragma mark - User服务
typedef NS_ENUM(NSInteger ,MSModulearViewType) {
    MSModulearViewTypeNone                              = 0,
    MSModulearViewTypeCaseOne                            = 1,
    MSModulearViewTypeCaseTwo                            = 2,
};

@protocol MSModulearOneProtocol <MSService>

- (void)gotoUserControllerWithType:(MSModulearViewType)type andParams:(NSDictionary *)params;

@end


