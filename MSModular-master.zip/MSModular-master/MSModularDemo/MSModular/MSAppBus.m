//
//  MSAppBus.m
//
//
//  Created by J on 2017/3/8.
//  Copyright © 2017年 J. All rights reserved.
//

#import "MSAppBus.h"
#import "MSService.h"
#import "MSSafeMutableArray.h"
#import "MSSafeMutableDictionary.h"
#import "MSCrashProtector.h"

static MSSafeMutableDictionary   *_serviceClasses;
static MSSafeMutableDictionary   *_unitClasses;

@interface MSAppBus()

@property(nonatomic,strong)MSSafeMutableDictionary *serviceContainer;
@end

@implementation MSAppBus


+ (instancetype)sharedBus{
    
    static MSAppBus *context = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        context = [[self alloc] init];
    });
    return context;
}

- (MSSafeMutableDictionary * )serviceContainer{
    
    // lifeCircle belong to MSUser
    return _serviceContainer;
}

- (MSSafeMutableDictionary *)unitClassDictionary{
    
    // todo
    return nil;
}

- (MSSafeMutableDictionary *)serviceClasses{
    
    return (_serviceClasses ? _serviceClasses : (_serviceClasses = [[MSSafeMutableDictionary alloc] init]));
}

- (MSSafeMutableDictionary *)unitClasses{
    
    return (_unitClasses ? _unitClasses : (_unitClasses = [[MSSafeMutableDictionary alloc] init]));
}

- (id)init{
    
    self = [super init];
    if (self) {
        _unitClasses = [[MSSafeMutableDictionary alloc] init];
        _serviceClasses = [[MSSafeMutableDictionary alloc] init];
        _serviceContainer = [[MSSafeMutableDictionary alloc] init];
    }
    return self;
}

+ (id)element:(Class)aclass;{
    
    NSParameterAssert(aclass != nil);
    if (!aclass) return nil;
    MSAppBus *appBus = [MSAppBus sharedBus];
    id <MSService> element = [[appBus serviceContainer] objectForKey:NSStringFromClass(aclass)];
    if (element) return element;
    
    id elementInstance = [[aclass alloc] init];
    if ([elementInstance respondsToSelector:@selector(serviceDidInit)]) {
        [elementInstance serviceDidInit];
    }
    [[appBus serviceContainer] setObjectSafe:elementInstance forKey:NSStringFromClass(aclass)];
    return elementInstance;
}

+ (void)registerService:(Protocol *)serviceProtocol withImplementClass:(Class)implClass{
    
    NSParameterAssert(serviceProtocol != nil);
    NSParameterAssert(implClass != nil);
    if (!serviceProtocol || !implClass) return;
    MSAppBus *appBus = [MSAppBus sharedBus];
    [[appBus serviceClasses] setObjectSafe:implClass forKey:NSStringFromProtocol(serviceProtocol)];
}

+ (id)service:(Protocol *)serviceProtocol{
    
    NSParameterAssert(serviceProtocol != nil);
    if (!serviceProtocol) return nil;
    MSAppBus *appBus = [MSAppBus sharedBus];
    id <MSService> service = [[appBus serviceContainer] objectForKey:NSStringFromProtocol(serviceProtocol)];
    if (service) return service;
    
    Class serviceClass = [[appBus serviceClasses] objectForKey:NSStringFromProtocol(serviceProtocol)];
    id serviceInstance = [[serviceClass alloc] init];
    if ([serviceInstance respondsToSelector:@selector(serviceDidInit)]) {
        [serviceInstance serviceDidInit];
    }
    [[appBus serviceContainer] setObjectSafe:serviceInstance forKey:NSStringFromProtocol(serviceProtocol)];
    
    return serviceInstance;
}

+ (BOOL)existService:(Protocol *)serviceProtocol{
    
    NSParameterAssert(serviceProtocol != nil);
    MSAppBus *appBus = [MSAppBus sharedBus];
    id obj = [[appBus serviceContainer] objectForKey:NSStringFromProtocol(serviceProtocol)];
    return obj? YES : NO;
}

+ (Class)unit:(Protocol*)unitProtocol{
    
    NSParameterAssert(unitProtocol != nil);
    if (!unitProtocol) return nil;
    MSAppBus *appBus = [MSAppBus sharedBus];
    Class unitClass = [[appBus unitClasses] objectForKey:NSStringFromProtocol(unitProtocol)];
    return unitClass ? unitClass : nil;
}

+ (BOOL)existUnit:(Protocol *)unitProtocol{
    
    NSParameterAssert(unitProtocol != nil);
    if (!unitProtocol) return nil;
    MSAppBus *appBus = [MSAppBus sharedBus];
    Class unitClass = [[appBus unitClasses] objectForKey:NSStringFromProtocol(unitProtocol)];
    return unitClass ? YES : NO;
}

+ (void)registerUnit:(Protocol *)unitProtocol withUnitClass:(Class)implClass{
    
    NSParameterAssert(unitProtocol != nil);
    NSParameterAssert(implClass != nil);
    if (!unitProtocol || !implClass) return;
    MSAppBus *appBus = [MSAppBus sharedBus];
    [[appBus unitClasses] setObjectSafe:implClass forKey:NSStringFromProtocol(unitProtocol)];
}

@end
